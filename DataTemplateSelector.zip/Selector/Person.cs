﻿using System;

namespace Selector
{
    public class Person
    {
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Location { get; set; }
    }
}
